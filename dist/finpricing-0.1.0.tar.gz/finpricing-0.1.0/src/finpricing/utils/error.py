class NotSupportedError(Exception):
    pass
